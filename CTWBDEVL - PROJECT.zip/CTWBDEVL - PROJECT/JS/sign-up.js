document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('sign-up-form');
    const messageContainer = document.getElementById('message-container');

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const username = form.username.value.trim();
        const email = form.email.value.trim();
        const password = form.password.value.trim();

        if (validateForm(username, email, password)) {
            const isRegistered = registerUser(username, email, password);

            if (isRegistered) {
                showMessage('Sign-up successful!', 'success');
            } else {
                showMessage('Sign-up failed. Please try again.', 'error');
            }
        }
    });

    function validateForm(username, email, password) {
        if (!username || !email || !password) {
            showMessage('All fields are required!', 'error');
            return false;
        }

        if (username.length > 8) {
            showMessage('Username must be at most 8 characters long.', 'error');
            return false;
        }

        if (!validateEmail(email)) {
            showMessage('Invalid email address.', 'error');
            return false;
        }

        return true;
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function showMessage(message, type) {
        messageContainer.textContent = message;
        messageContainer.className = type; // Use 'success' or 'error' class for styling
    }

    function registerUser(username, email, password) {
        // Store the user's email and password in localStorage
        localStorage.setItem('registeredUser', JSON.stringify({ email, password }));
        return true;
    }
});
