document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('sign-in-form');
    const messageContainer = document.getElementById('message-container');

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const email = form.email.value.trim();
        const password = form.password.value.trim();

        if (validateForm(email, password)) {
            const isAuthenticated = authenticateUser(email, password);

            if (isAuthenticated) {
                showMessage('Sign-in successful!', 'success');
                // Redirect to another page after successful sign-in
                window.location.href = 'dashboard.html'; // Replace with your desired URL
            } else {
                showMessage('Sign-in failed. Invalid email or password.', 'error');
            }
        }
    });

    function validateForm(email, password) {
        if (!email || !password) {
            showMessage('All fields are required!', 'error');
            return false;
        }

        if (!validateEmail(email)) {
            showMessage('Invalid email address.', 'error');
            return false;
        }

        return true;
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function showMessage(message, type) {
        messageContainer.textContent = message;
        messageContainer.className = type; // Use 'success' or 'error' class for styling
    }

    function authenticateUser(email, password) {
        // Retrieve the registered user data from localStorage
        const registeredUser = JSON.parse(localStorage.getItem('registeredUser'));

        if (!registeredUser) {
            showMessage('No registered user found.', 'error');
            return false;
        }

        // Check the email and password against the registered user data
        return email === registeredUser.email && password === registeredUser.password;
    }
});