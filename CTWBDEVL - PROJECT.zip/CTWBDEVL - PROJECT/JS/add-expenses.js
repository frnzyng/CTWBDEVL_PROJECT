var sidebarOpen = false;
var sidebar = document.getElementById("sidebar");

function openSidebar() {
    if (!sidebarOpen) {
        sidebar.classList.add("sidebar-responsive");
        sidebarOpen = true;
    }
}

function closeSidebar() {
    if (sidebarOpen) {
        sidebar.classList.remove("sidebar-responsive");
        sidebarOpen = false;
    }
}

function navigateTo(url) {
    window.location.href = url;
}
function toggleAccountInfo() {
    var accountInfo = document.getElementById('accountInfo');
    accountInfo.style.display = accountInfo.style.display === 'block' ? 'none' : 'block';
}


// Close account info on click outside
document.addEventListener('click', function(event) {
    var accountIcon = document.querySelector('.account-icon');
    var accountInfo = document.getElementById('accountInfo');
    var isClickInsideAccountIcon = accountIcon.contains(event.target);
    var isClickInsideAccountInfo = accountInfo.contains(event.target);

    if (!isClickInsideAccountIcon && !isClickInsideAccountInfo) {
        accountInfo.style.display = 'none';
    }
});

// add button
function handleButtonClick() {
    // Show the modal
    document.getElementById('modal').style.display = 'block';
    // Add blur to the background
    document.body.classList.add('blur');
}

function closeModal() {
    // Hide the modal
    document.getElementById('modal').style.display = 'none';
    // Remove blur from the background
    document.body.classList.remove('blur');
    // Navigate to expenses.html
    window.location.href = 'expenses.html';
}


// logout
function logoutButtonClick() {
    // Show the modal
    document.getElementById('logout-modal').style.display = 'block';
    // Add blur to the background
    document.body.classList.add('blur');
}

function closeLogoutModal() {
    // Hide the modal
    document.getElementById('logout-modal').style.display = 'none';
    // Remove blur from the background
    document.body.classList.remove('blur');
    // Navigate to expenses.html
    window.location.href = 'expenses.html';
}


// ANIMATION
$(document).ready(function() {
    // Function to load content from another HTML page
    function loadContent(pageUrl) {
        // Add new-content class to trigger animation
        $('#mainContainer').addClass('new-content');
        // Load content after animation delay
        setTimeout(function() {
            $('#mainContainer').load(pageUrl + ' #mainContainer > *', function() {
                // Remove new-content class after loading new content
                $(this).removeClass('new-content');
            });
        }, 500); // Adjust delay time to match animation duration
    }

    // Example: Load content when a link is clicked
    $('a').on('click', function(event) {
        event.preventDefault(); // Prevent default link behavior
        var pageUrl = $(this).attr('href'); // Get href attribute of clicked link
        loadContent(pageUrl); // Call function to load content
    });
});