 
      var sidebarOpen = false;
      var sidebar = document.getElementById("sidebar");
      
      function openSidebar() {
          if (!sidebarOpen) {
              sidebar.classList.add("sidebar-responsive");
              sidebarOpen = true;
          }
      }
      
      function closeSidebar() {
          if (sidebarOpen) {
              sidebar.classList.remove("sidebar-responsive");
              sidebarOpen = false;
          }
      }
      function navigateTo(url) {
        window.location.href = url;
    }

    function toggleAccountInfo() {
      var accountInfo = document.getElementById('accountInfo');
      accountInfo.style.display = accountInfo.style.display === 'block' ? 'none' : 'block';
  }
  
  
  // Close account info on click outside
  document.addEventListener('click', function(event) {
      var accountIcon = document.querySelector('.account-icon');
      var accountInfo = document.getElementById('accountInfo');
      var isClickInsideAccountIcon = accountIcon.contains(event.target);
      var isClickInsideAccountInfo = accountInfo.contains(event.target);
  
      if (!isClickInsideAccountIcon && !isClickInsideAccountInfo) {
          accountInfo.style.display = 'none';
      }
  });
  
  

// add button
function handleButtonClick() {
  // Show the modal
  document.getElementById('modal').style.display = 'block';
  // Add blur to the background
  document.body.classList.add('blur');
}

function closeModal() {
  // Hide the modal
  document.getElementById('modal').style.display = 'none';
  // Remove blur from the background
  document.body.classList.remove('blur');
  // Navigate to expenses.html
  window.location.href = 'home.html';
}
      
      function setActive(id) {
          // Remove active class from all buttons
          const buttons = document.querySelectorAll('.view-option');
          buttons.forEach(button => button.classList.remove('active'));
      
          // Add active class to the clicked button
          const activeButton = document.getElementById(id);
          activeButton.classList.add('active');
      
          // Call the appropriate function based on the selected view option
          if (id === 'daily') {
              handleDailyView();
          } else if (id === 'weekly') {
              handleWeeklyView();
          } else if (id === 'monthly') {
              handleMonthlyView();
          } 
      }
      
      var chartOptions = {
          series: [
            { name: "Money Saved", data: [-300, -50, 85, 30, -10, -250, 50] },
                  { name: "Money Spent", data: [500, 250, 115, 170, 210, 450, 150] }
          ],
          chart: {
            height: 350,
            type: 'line',
            dropShadow: {
              enabled: true,
              color: '#000',
              top: 18,
              left: 7,
              blur: 10,
              opacity: 0.2
            },
            zoom: {
              enabled: false
            },
            toolbar: {
              show: true, // Set to true to display the toolbar
              tools: {
                  download: true, // Enable download button in the toolbar
              },
              autoSelected: 'zoom' // Initially selected tool (zoom or pan)
          }
          },
          colors: ['#8CB8A3', '#E05252'],
          dataLabels: {
            enabled: true,
          },
          stroke: {
            curve: 'smooth'
          },
          title: {
            text: 'Daily Spending and Saving',
            align: 'left'
          },
          grid: {
            borderColor: '#e7e7e7',
            row: {
              colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
              opacity: 0.5
            },
          },
          markers: {
            size: 1
          },
          xaxis: {
            categories: ['Jun 12', 'Jun 13', 'Jun 14', 'Jun 15', 'Jun 16', 'Jun 17', 'Jun 18'],
          title: {
              text: 'Date'
            }
          },
          yaxis: {
            title: {
              text: ''
            },
            min: -400,
            max: 1000
          },
          legend: {
            position: 'top',
            horizontalAlign: 'right',
            floating: true,
            offsetY: -25,
            offsetX: -5
          }
          };
      
      var chart = new ApexCharts(document.querySelector("#line-chart"), chartOptions);
      chart.render();
      
      // Update chart options based on the selected view
      function updateChart(options) {
          chart.updateOptions(options);
      }
      
      // DAILY
      function handleDailyView() {
          // Logic for handling the daily view option
          console.log('Daily view selected');
          
          // MONEY 
          var moneyAmountElement = document.getElementById('money-amount');
          // Update the content of the h1 element
          moneyAmountElement.textContent = 200;
      
          // SPENT
          var spentAmountElement = document.getElementById('spent-amount');
          // Update the content of the h1 element
          spentAmountElement.textContent = 150;
      
          // SAVE
          var savedAmountElement = document.getElementById('saved-amount');
          // Update the content of the h1 element
          savedAmountElement.textContent = 50;

          var dateCalendarElement = document.getElementById('date-calendar');
          // Update the content of the h1 element
          dateCalendarElement.textContent = 'June 18, 2024';
      
          // Line chart data for daily view
          var options = {
              series: [
                  { name: "Money Saved", data: [-300, -50, 85, 30, -10, -250, 50] },
                  { name: "Money Spent", data: [500, 250, 115, 170, 210, 450, 150] }
              ],
              xaxis: { categories: ['Jun 12', 'Jun 13', 'Jun 14', 'Jun 15', 'Jun 16', 'Jun 17', 'Jun 18'], title:{ text:'Date'}},
              yaxis: { min: -400, max: 1000 },
              title: { text: 'Daily Spending and Saving', align: 'left' }
          };
      
          updateChart(options);
      }
      
      // WEEKLY
      function handleWeeklyView() {
          // Logic for handling the weekly view option
          console.log('Weekly view selected');
          
          // MONEY 
          var moneyAmountElement = document.getElementById('money-amount');
          // Update the content of the h1 element
          moneyAmountElement.textContent = 1400;
      
          // SPENT
          var spentAmountElement = document.getElementById('spent-amount');
          // Update the content of the h1 element
          spentAmountElement.textContent = 700;
      
          // SAVE
          var savedAmountElement = document.getElementById('saved-amount');
          // Update the content of the h1 element
          savedAmountElement.textContent = 700;

          var dateCalendarElement = document.getElementById('date-calendar');
          // Update the content of the h1 element
          dateCalendarElement.textContent = 'June 17-30';
      
          // Line chart data for weekly view
          var options = {
              series: [
                  { name: "Money Saved", data: [-100, 150, 285, 230, 190, 250, 700] },
                  { name: "Money Spent", data: [1500, 1250, 1115, 1170, 1210, 1150, 700] }
              ],
              xaxis: { categories: ['May 13-19', 'May 20-26', 'May 27-2', 'May 27-J2', 'Jun 3-9', 'Jun 10-16', 'Jun 17-23'], title:{ text:'Date'} },
              yaxis: { min: -1000, max: 2000 },
              title: { text: 'Weekly Spending and Saving', align: 'left' }
          };
      
          updateChart(options);
      }
      
      // MONTHLY
      function handleMonthlyView() {
          // Logic for handling the monthly view option
          console.log('Monthly view selected');
          
          // MONEY 
          var moneyAmountElement = document.getElementById('money-amount');
          // Update the content of the h1 element
          moneyAmountElement.textContent = 6000;
      
          // SPENT
          var spentAmountElement = document.getElementById('spent-amount');
          // Update the content of the h1 element
          spentAmountElement.textContent = 2395;
      
          // SAVE
          var savedAmountElement = document.getElementById('saved-amount');
          // Update the content of the h1 element
          savedAmountElement.textContent = 3605;

          var dateCalendarElement = document.getElementById('date-calendar');
          // Update the content of the h1 element
          dateCalendarElement.textContent = 'June 2024';
      
          // Line chart data for monthly view
          var options = {
              series: [
                  { name: "Money Saved", data: [500, 750, 885, 1830, 880, -150, 3605] },
                  { name: "Money Spent", data: [5500, 5250, 5115, 4170, 5210, 6150, 2395] }
              ],
              xaxis: { categories: ['Dec 2023', 'Jan 2024', 'Feb 2024', 'Mar 2024', 'Apr 2024', 'May 2024', 'Jun 2024'], title:{ text:'Month'} },
              yaxis: { min: -1000, max: 7000 },
              title: { text: 'Monthly Spending and Saving', align: 'left' }
          };
      
          updateChart(options);
      }
      

    // HISTORY
var expensesData = [
    { Description: 'Groceries', Date: '2024-05-18', Spent: 500.00 },
    { Description: 'Lunch', Date: '2024-05-18', Spent: 150.00 },
    { Description: 'Utilities', Date: '2024-05-17', Spent: 300.00 },
    { Description: 'Dinner', Date: '2024-05-17', Spent: 150.00 },
    { Description: 'Dinner with friends', Date: '2024-05-16', Spent: 180.00 },
    { Description: 'Transportation', Date: '2024-05-16', Spent: 30.00 },
    { Description: 'Dinner', Date: '2024-05-15', Spent: 100.00 },
];

// Function to generate the table
function generateTable(data) {
    var table = '<table>';
    table += '<tr><th>Description</th><th>Date</th><th>Spent</th></tr>';
    data.forEach(function(expense) {
        table += '<tr>';
        table += '<td>' + expense.Description + '</td>';
        table += '<td>' + expense.Date + '</td>';
        table += '<td>' + expense.Spent.toFixed(2) + '</td>';
        table += '</tr>';
    });
    table += '</table>';
    return table;
}

// Get the table chart div
var tableChartDiv = document.getElementById('table-chart');
// Generate the table and insert it into the div
tableChartDiv.innerHTML = generateTable(expensesData);


// ANIMATION
$(document).ready(function() {
  // Function to load content from another HTML page
  function loadContent(pageUrl) {
      // Add new-content class to trigger animation
      $('#mainContainer').addClass('new-content');
      // Load content after animation delay
      setTimeout(function() {
          $('#mainContainer').load(pageUrl + ' #mainContainer > *', function() {
              // Remove new-content class after loading new content
              $(this).removeClass('new-content');
          });
      }, 500); // Adjust delay time to match animation duration
  }

  // Example: Load content when a link is clicked
  $('a').on('click', function(event) {
      event.preventDefault(); // Prevent default link behavior
      var pageUrl = $(this).attr('href'); // Get href attribute of clicked link
      loadContent(pageUrl); // Call function to load content
  });
});
  