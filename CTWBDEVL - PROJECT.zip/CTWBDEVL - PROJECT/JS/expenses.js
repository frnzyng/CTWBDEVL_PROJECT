var sidebarOpen = false;
var sidebar = document.getElementById("sidebar");

function openSidebar() {
    if (!sidebarOpen) {
        sidebar.classList.add("sidebar-responsive");
        sidebarOpen = true;
    }
}

function closeSidebar() {
    if (sidebarOpen) {
        sidebar.classList.remove("sidebar-responsive");
        sidebarOpen = false;
    }
}

function navigateTo(url) {
    window.location.href = url;
}

function toggleAccountInfo() {
    var accountInfo = document.getElementById('accountInfo');
    accountInfo.style.display = accountInfo.style.display === 'block' ? 'none' : 'block';
}


// Close account info on click outside
document.addEventListener('click', function(event) {
    var accountIcon = document.querySelector('.account-icon');
    var accountInfo = document.getElementById('accountInfo');
    var isClickInsideAccountIcon = accountIcon.contains(event.target);
    var isClickInsideAccountInfo = accountInfo.contains(event.target);

    if (!isClickInsideAccountIcon && !isClickInsideAccountInfo) {
        accountInfo.style.display = 'none';
    }
});

// add button
function handleButtonClick() {
    // Show the modal
    document.getElementById('modal').style.display = 'block';
    // Add blur to the background
    document.body.classList.add('blur');
  }
  
  function closeModal() {
    // Hide the modal
    document.getElementById('modal').style.display = 'none';
    // Remove blur from the background
    document.body.classList.remove('blur');
    // Navigate to expenses.html
    window.location.href = 'home.html';
  }

var expensesData = [
    { Description: 'Groceries', Date: '2024-05-18', Spent: 500.00, Image: '../images/grocery.png' },
    { Description: 'Lunch', Date: '2024-05-18', Spent: 150.00 },
    { Description: 'Utilities', Date: '2024-05-17', Spent: 300.00, Image: '../images/utilities.png' },
    { Description: 'Dinner', Date: '2024-05-17', Spent: 150.00 },
    { Description: 'Dinner with friends', Date: '2024-05-16', Spent: 180.00 },
    { Description: 'Transportation', Date: '2024-05-16', Spent: 30.00 },
    { Description: 'Dinner', Date: '2024-05-15', Spent: 100.00 },
    { Description: 'Lunch', Date: '2024-05-15', Spent: 70.00 },
    { Description: 'Snack', Date: '2024-05-14', Spent: 100.00 },
    { Description: 'Transportation', Date: '2024-05-14', Spent: 15.00 },
    { Description: 'Movies', Date: '2024-05-13', Spent: 250.00, Image: '../images/movie.png' },
    { Description: 'Shopping', Date: '2024-05-12', Spent: 500.00, Image: '../images/shopping12.png' },
    { Description: 'Shopping', Date: '2024-05-11', Spent: 150.00, Image: '../images/shopping10.png' },
    { Description: 'Dinner', Date: '2024-05-10', Spent: 150.00 }
];

// Function to generate the table
function generateTable(data) {

    var table = '<table>';
    table += '<tr><th>Description</th><th>Date</th><th>Spent</th><th>Image</th></tr>';
    data.forEach(function(expense) {
        table += '<tr>';
        table += '<td>' + expense.Description + '</td>';
        table += '<td>' + expense.Date + '</td>';
        table += '<td>' + expense.Spent.toFixed(2) + '</td>';
        if (expense.Image) {
            table += '<td><img src="'+ expense.Image + '" class="expense-img" onclick="openFullscreenImage(\'' + expense.Image + '\')"></td>';
        } else {
            table += '<td></td>';
        }
        table += '</tr>';
    });
    table += '</table>';
    return table;

}

// Function to filter expenses by selected date
function filterExpensesByDate(date) {
    return expensesData.filter(expense => expense.Date === date);
}

// Function to create calendar
function createCalendar(year, month) {
    const calendar = document.getElementById('calendar');
    calendar.innerHTML = '';

    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const firstDay = new Date(year, month, 1).getDay();

    for (let i = 0; i < firstDay; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.classList.add('day');
        calendar.appendChild(emptyCell);
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const dayCell = document.createElement('div');
        dayCell.classList.add('day');
        dayCell.textContent = day;
        dayCell.onclick = function() {
            const clickedDate = `${year}-${(month).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
            console.log('Clicked Date:', clickedDate); // Log clicked date for debugging
            const filteredExpenses = filterExpensesByDate(clickedDate);
            console.log('Filtered Expenses:', filteredExpenses); // Check if expenses are filtered correctly
            const expensesChartDiv = document.getElementById('expenses-chart');
            expensesChartDiv.innerHTML = generateTable(filteredExpenses);

        updateAmountsFromExpenses(filteredExpenses);
          
        // ALLOWANCE 
          var moneyAmountElement = document.getElementById('allowance-amount');
          // Update the content of the h1 element
          moneyAmountElement.textContent = 200; 


        };
        calendar.appendChild(dayCell);
    }

    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July',
                        'August', 'September', 'October', 'November', 'December'];
    document.getElementById('currentMonthYear').textContent = `${monthNames[month]} ${year}`;
}

// Function to initialize calendar and set up navigation
function initCalendar() {
    let today = new Date();
    let currentYear = today.getFullYear();
    let currentMonth = today.getMonth();
    createCalendar(currentYear, currentMonth);

    document.getElementById('prevMonthBtn').addEventListener('click', () => {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        createCalendar(currentYear, currentMonth);
    });

    document.getElementById('nextMonthBtn').addEventListener('click', () => {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        createCalendar(currentYear, currentMonth);
    });
}

// Initialize the calendar on page load
initCalendar();

function openFullscreenImage(imageUrl) {
    // Create a full screen container
    var fullscreenContainer = document.createElement('div');
    fullscreenContainer.classList.add('fullscreen-container');
    
    // Create an image element for full screen
    var fullscreenImage = document.createElement('img');
    fullscreenImage.src = imageUrl;
    fullscreenImage.classList.add('fullscreen-image');
    
    // Add the image to the container
    fullscreenContainer.appendChild(fullscreenImage);
    
    // Append the full screen container to the body
    document.body.appendChild(fullscreenContainer);
    
    // Add event listener to close full screen on click outside the image
    fullscreenContainer.addEventListener('click', closeFullscreenImage);
    
    // Function to close full screen image
    function closeFullscreenImage() {
        document.body.removeChild(fullscreenContainer);
    }
}

// Function to update spent and saved amounts based on filtered expenses
function updateAmountsFromExpenses(filteredExpenses) {
    var totalSpent = filteredExpenses.reduce((total, expense) => total + expense.Spent, 0);
    var totalSaved = 200 - totalSpent; // Fixed allowance is 200
    var spentAmountElement = document.getElementById('spent-amount');
    spentAmountElement.textContent = totalSpent.toFixed(2);
    var savedAmountElement = document.getElementById('saved-amount');
    savedAmountElement.textContent = totalSaved.toFixed(2);
}

// Function to update spent and saved amounts based on filtered expenses
function updateAmountsFromSearch(filteredExpenses) {
    var totalSpent = filteredExpenses.reduce((total, expense) => total + expense.Spent, 0);
    var spentAmountElement = document.getElementById('spent-amount');
    spentAmountElement.textContent = totalSpent.toFixed(2);
    var savedAmountElement = document.getElementById('saved-amount');
    savedAmountElement.textContent = ''; // Clear saved amount
    var allowanceAmountElement = document.getElementById('allowance-amount');
    allowanceAmountElement.textContent = ''; // Clear allowance amount
}


function filterExpensesByText(searchText) {
    if (!searchText) return expensesData; // If no search text, return all data

    searchText = searchText.toLowerCase();
    return expensesData.filter(function(expense) {
        return expense.Description.toLowerCase().includes(searchText);
    });
}

function searchForExpenses() {
    var searchText = document.getElementById('searchInput').value.trim();
    var filteredExpenses = filterExpensesByText(searchText);
    var expensesChartDiv = document.getElementById('expenses-chart');
    expensesChartDiv.innerHTML = generateTable(filteredExpenses);
    updateAmountsFromSearch(filteredExpenses);
}

// Initialize the calendar on page load
document.addEventListener('DOMContentLoaded', function() {
    initCalendar();
    
    // Handle search input on Enter key press
    document.getElementById('searchInput').addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            searchForExpenses();
        }
    });
});


// ANIMATION
$(document).ready(function() {
    // Function to load content from another HTML page
    function loadContent(pageUrl) {
        // Add new-content class to trigger animation
        $('#mainContainer').addClass('new-content');
        // Load content after animation delay
        setTimeout(function() {
            $('#mainContainer').load(pageUrl + ' #mainContainer > *', function() {
                // Remove new-content class after loading new content
                $(this).removeClass('new-content');
            });
        }, 500); // Adjust delay time to match animation duration
    }

    // Example: Load content when a link is clicked
    $('a').on('click', function(event) {
        event.preventDefault(); // Prevent default link behavior
        var pageUrl = $(this).attr('href'); // Get href attribute of clicked link
        loadContent(pageUrl); // Call function to load content
    });
});