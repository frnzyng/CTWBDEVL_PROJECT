document.addEventListener('DOMContentLoaded', function() {
  const menuIcon = document.getElementById('menu-icon');
  const dropdownMenu = document.getElementById('dropdown-menu');

  menuIcon.addEventListener('click', function() {
      dropdownMenu.classList.toggle('show');
  });

  window.addEventListener('resize', function() {
      if (window.innerWidth > 768) {
          dropdownMenu.classList.remove('show');
      }
  });
});